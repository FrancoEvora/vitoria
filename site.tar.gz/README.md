# Vitória — Solaris Residencial

Experiência pública de atendimento inteligente da Évora Urbanismo, publicada como site estático na Vercel e integrada ao Supabase.

## Recursos em produção

- Conversa com a Vitória, agente comercial com supervisão de IA.
- Consulta em tempo real do estoque de lotes, valores de tabela e política comercial vigente.
- Filtros por metragem e faixa de investimento.
- Captação com consentimento de contato separado do consentimento opcional de marketing.
- Solicitação transacional de bloqueio temporário de lote, com expiração automática e aprovação obrigatória por administrador ou diretoria.
- Painel `/admin` para listar, aprovar ou rejeitar solicitações pendentes.
- Integração com CRM, trilha de auditoria, alertas e tarefas internas.

## Arquitetura

- Frontend estático: HTML, CSS e JavaScript sem dependências de runtime.
- API pública: Supabase Edge Function `enterprise-public-agent-gateway`.
- Orquestração segura: `enterprise-public-agent` com autenticação interna, OpenAI e RPCs transacionais.
- Banco e governança: Supabase/PostgreSQL com RLS, funções `security definer` restritas e aprovação autenticada.

## Estrutura

```text
index.html
admin.html
app.js
admin.js
styles.css
supabase/
  functions/
  migrations/
```

A chave presente no frontend é a chave pública/publishable do Supabase. Segredos, service role e credenciais de IA permanecem apenas no ambiente server-side.
